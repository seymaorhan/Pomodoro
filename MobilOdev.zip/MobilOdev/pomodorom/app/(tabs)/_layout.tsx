import { Tabs } from 'expo-router';
import React from 'react';
import { Text } from 'react-native'; // <--- !!! YENİ EKLEME !!!
// Diğer importlar...
import { HapticTab } from '@/components/haptic-tab';
// import { IconSymbol } from '@/components/ui/icon-symbol'; // ARTIK İHTİYAÇ YOK
import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';

export default function TabLayout() {
  const colorScheme = useColorScheme();
  
  // Emoji boyutu için sabit tanımlama (IconSymbol'deki 28'e eşdeğer)
  const EMOJI_SIZE = 28;

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: Colors[colorScheme ?? 'light'].tint,
        headerShown: false,
        tabBarButton: HapticTab,
      }}
    >

      {/* 1 — ANA SAYFA */}
      <Tabs.Screen
        name="index"
        options={{
          title: 'Ana Sayfa',
          tabBarIcon: ({ color }) => (
            // Ev ikonu için Unicode kullanıyoruz
            <Text style={{ fontSize: 23, color: color }}>🏠</Text>
          ),
        }}
      />

      {/* 2 — RAPORLAR */}
      <Tabs.Screen
        name="reports"
        options={{
          title: 'Raporlar',
          tabBarIcon: ({ color }) => (
            // 📊 Raporlar için: Büyüyen Grafik emojisi
            <Text style={{ fontSize: 23, color: color }}>📈</Text>
          ),
        }}
      />

      {/* 3 — MOTİVASYON */}
      <Tabs.Screen
        name="motivation"
        options={{
          title: 'Motivasyon',
          tabBarIcon: ({ color }) => (
            // ✨ Motivasyon için: Parıltı/Yıldız emojisi
            <Text style={{ fontSize: 23, color: color }}>✨</Text>
          ),
        }}
      />

    </Tabs>
  );
}
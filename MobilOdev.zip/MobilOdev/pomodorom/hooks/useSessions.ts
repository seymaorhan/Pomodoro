import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useState } from "react";

export type Session = {
  duration: number;
  category: string;
  date: string;
  distractions: number;
};

const STORAGE_KEY = "SESSIONS_DATA";

export function useSessions() {
  const [sessions, setSessions] = useState<Session[]>([]);

  // Load sessions
  useEffect(() => {
    (async () => {
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      if (raw) {
        setSessions(JSON.parse(raw));
      }
    })();
  }, []);

  // Save new session
  const saveSession = async (
    duration: number,
    category: string,
    distractions: number
  ) => {
    const newSession: Session = {
      duration,
      category,
      distractions,
      date: new Date().toISOString(),
    };

    const updated = [...sessions, newSession];
    setSessions(updated);

    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  return {
    sessions,
    saveSession,
  };
}
